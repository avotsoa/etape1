<?php
// Footer commun
?>
<footer class="text-center mt-5">
    <p>&copy; <?php echo date('Y'); ?> Raryy. Tous droits réservés.</p>
</footer>
</body>
</html> 