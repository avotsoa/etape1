<?php
session_start();
require_once '../includes/db.php';
require_once '../includes/function.php';
include '../includes/header.php';
?>
<div class="container mt-5">
    <h2>Emprunter un objet</h2>
    <!-- Formulaire ou informations d'emprunt ici -->
</div>
<?php include '../includes/footer.php'; ?> 