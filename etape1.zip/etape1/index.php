<?php
// Page d'accueil
header('Location: pages/login.php');
exit; 